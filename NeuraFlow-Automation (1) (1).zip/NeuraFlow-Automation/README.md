# NeuraFlow Automation – AI Automation Agency

## Team Name
**Web Wizards**

## Team Members
- Ragavi G (Team Lead)
- Brindha B
- Satyajit S
- Yogasri S
- Vikashini M

## Project Overview
NeuraFlow Automation is a responsive frontend website designed for an AI automation agency.  
The website presents AI-driven automation services and provides a modern, professional web presence for businesses looking to streamline their operations using intelligent automation solutions.

## Objectives
- To design a clean and professional website for an AI automation agency  
- To showcase AI-based automation services  
- To create a responsive and user-friendly interface  
- To simulate a real-world agency portfolio website  

## Features
- Modern landing page with hero section  
- About section describing the agency  
- Services section highlighting AI automation offerings  
- Why Choose Us section showing business advantages  
- Contact form with frontend validation  
- Responsive design suitable for desktop and mobile devices  

## Technologies Used
- **HTML5** – Structure of the website  
- **CSS3** – Styling, layout, animations, and responsiveness  
- **JavaScript** – Form interaction and success message display  

## Project Structure
NeuraFlow-Automation/ │ ├── index.html ├── style.css ├── script.js └── README.md

## Team Roles and Responsibilities
- **Ragavi G (Team Lead):** Project planning, team coordination, integration of files, testing, and final submission  
- **Brindha B:** HTML structure and layout  
- **Satyajit S:** CSS styling, animations, and responsive design  
- **Yogasri S:** JavaScript functionality and form handling  
- **Vikashini M:** Content writing and documentation  

## How to Run the Project
1. Download or clone the project folder  
2. Open the folder in VS Code  
3. Open `index.html` in any modern web browser  
4. The website will load without requiring any backend setup  

## Conclusion
This project demonstrates the creation of a professional AI automation agency website using core web technologies. It highlights teamwork, frontend development skills, and effective project coordination within a short internship duration.

---

© 2025 NeuraFlow Automation | Team Web Wizards