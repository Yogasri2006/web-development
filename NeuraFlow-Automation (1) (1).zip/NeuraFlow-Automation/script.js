// NeuraFlow Automation - JavaScript

const form = document.querySelector("form");
const msg = document.getElementById("successMsg");

if (form) {
  form.addEventListener("submit", function (e) {
    e.preventDefault();
    msg.style.display = "block";
    form.reset();
  });
}
